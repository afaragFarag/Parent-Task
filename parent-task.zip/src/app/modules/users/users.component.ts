import { Component } from '@angular/core';

@Component({
  selector: 'app-users',
  template: `
    <router-outlet></router-outlet>
  `
})
export class UsersComponent {}
