import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminstration',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdminstrationComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
