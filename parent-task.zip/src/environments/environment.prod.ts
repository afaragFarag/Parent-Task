export const environment = {
  production: true,
  baseUrl : 'https://reqres.in/'
};
